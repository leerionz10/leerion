-- Run this in Supabase Dashboard > SQL Editor.
create table if not exists public.storyphone_config (
  id text primary key check (id = 'main'),
  config jsonb not null default '{}'::jsonb,
  updated_at timestamptz not null default now()
);

alter table public.storyphone_config enable row level security;

-- Everyone can read the published phone content.
drop policy if exists "Public can read StoryPhone config" on public.storyphone_config;
create policy "Public can read StoryPhone config"
on public.storyphone_config for select
to anon, authenticated
using (id = 'main');

-- Only a user whose app_metadata.role is 'admin' can publish changes.
-- Set this role for your own user from Supabase Dashboard / trusted admin tooling.
drop policy if exists "Only admins can update StoryPhone config" on public.storyphone_config;
create policy "Only admins can update StoryPhone config"
on public.storyphone_config for all
to authenticated
using (
  id = 'main'
  and (auth.jwt() -> 'app_metadata' ->> 'role') = 'admin'
)
with check (
  id = 'main'
  and (auth.jwt() -> 'app_metadata' ->> 'role') = 'admin'
);

grant select on public.storyphone_config to anon, authenticated;
grant insert, update, delete on public.storyphone_config to authenticated;
